"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};

var MARKER = 43; // +
var MARKER_OPEN = 62; // >
function renderSummary(tokens, idx, options, env, self) {
    var title = self.render(tokens[idx].children, options, env);
    return "<summary>".concat(title, "</summary>");
}
function skipMarker(state, start) {
    var isOpen = false;
    // First, skip all `+` characters
    var pos = state.skipChars(start, MARKER);
    // If the next character is `>`, then we are in open state
    if (state.src.charCodeAt(pos) === MARKER_OPEN) {
        pos++;
        isOpen = true;
    }
    var markerCount = pos - start;
    var marker = String.fromCharCode(MARKER).repeat(Math.max(markerCount - 1, 0)) + (isOpen ? ">" : "+");
    return { pos: pos, isOpen: isOpen, markerCount: markerCount, marker: marker };
}
/**
 * The core plugin which checks for the appropriate prefix content of
 * either `+++` (for collapsible blocks in closed state) or `++>` (for
 * collapsible blocks in open state).
 */
function parseCollapsible(state, startLine, endLine, silent) {
    var autoClosedBlock = false;
    var start = state.bMarks[startLine] + state.tShift[startLine];
    var max = state.eMarks[startLine];
    // The block must start with `+++` or `++>`
    var _a = skipMarker(state, start), pos = _a.pos, isOpen = _a.isOpen, markerCount = _a.markerCount, marker = _a.marker;
    if (markerCount < 3)
        return false;
    /** The characters of the **summary** section */
    var params = state.src.slice(pos, max).trim();
    // Title must not be empty
    if (isWhitespace(state, pos, max))
        return false;
    // The title must not end with the marker (no inline)
    if (params.endsWith(marker))
        return false;
    // Since start is found, we can report success here in validation mode
    if (silent)
        return true;
    // Search the end of the block
    var nextLine = startLine;
    var isEmpty = true;
    for (;;) {
        nextLine++;
        // Unclosed block should be autoclosed by end of document.
        if (nextLine >= endLine)
            break;
        start = state.bMarks[nextLine] + state.tShift[nextLine];
        max = state.eMarks[nextLine];
        // Non-empty line with negative indent should stop the list:
        // - ```
        //  test
        if (start < max && state.sCount[nextLine] < state.blkIndent)
            break;
        if (state.src.charCodeAt(start) !== (MARKER)) {
            if (isEmpty)
                isEmpty = isWhitespace(state, start, max);
            continue;
        }
        // Closing marker should be indented less than 4 spaces
        if (state.sCount[nextLine] - state.blkIndent >= 4)
            continue;
        var endMarker = skipMarker(state, start);
        pos = endMarker.pos;
        // Closing marker must match opening marker
        if (endMarker.marker !== marker)
            continue;
        // Make sure tail has spaces only
        pos = state.skipSpaces(pos);
        if (pos < max)
            continue;
        autoClosedBlock = true;
        break;
    }
    if (isEmpty)
        return false;
    var oldParent = state.parentType;
    var oldLineMax = state.lineMax;
    state.parentType = "reference";
    // This will prevent lazy continuations from ever going past our end marker
    state.lineMax = nextLine;
    // Push the tokens to the state
    var token = state.push("collapsible_open", "details", 1);
    token.block = true;
    token.info = params;
    token.markup = marker;
    token.map = [startLine, nextLine];
    if (isOpen)
        token.attrSet("open", "");
    // Tokenize the summary content
    var tokens = [];
    var markerToken = new state.Token("collapsible_marker", "span", 1);
    markerToken.attrs = [["class", "details-marker"]];
    var markerTokens = [markerToken, new state.Token("collapsible_marker", "span", -1)];
    // It doesn't make sense to have block level elements inside the summary,
    // except for headings. Thus, a simple check is performed to see if the
    // summary content is a heading.
    if (params.match(/^#{1,6}/)) {
        tokens = state.md.parse(params, state.env);
        var headingToken = tokens.shift();
        if (headingToken)
            tokens.unshift.apply(tokens, __spreadArray([headingToken], markerTokens, false));
    }
    // Otherwise, we parse everything as inline
    else {
        state.md.inline.parse(params, state.md, state.env, tokens);
        tokens.unshift.apply(tokens, markerTokens);
    }
    token = state.push("collapsible_summary", "summary", 0);
    token.content = params;
    token.children = tokens;
    state.md.block.tokenize(state, startLine + 1, nextLine);
    token = state.push("collapsible_close", "details", -1);
    token.markup = state.src.slice(start, pos);
    token.block = true;
    state.parentType = oldParent;
    state.lineMax = oldLineMax;
    state.line = nextLine + (autoClosedBlock ? 1 : 0);
    return true;
}
function isWhitespace(state, start, end) {
    for (start; start < end; start++) {
        if (!state.md.utils.isWhiteSpace(state.src.charCodeAt(start)))
            return false;
    }
    return true;
}
/**
 * A markdown-it plugin, which allows authors to create a block of content, which can be toggled between
 * an open and closed state. Use `+++` to start in closed state and `++>` to render an open collapsible block by default.
 *
 * @example
 * ```md
 * +++ Click to open
 * This content is
 * - hidden
 * - invisible
 * - collapsed
 * +++
 * ```
 */
function collapsiblePlugin(md) {
    md.block.ruler.before("fence", "collapsible", parseCollapsible, {
        alt: ["paragraph", "reference", "blockquote", "list"],
    });
    md.renderer.rules.collapsible_summary = renderSummary;
}
module.exports = collapsiblePlugin;
;
